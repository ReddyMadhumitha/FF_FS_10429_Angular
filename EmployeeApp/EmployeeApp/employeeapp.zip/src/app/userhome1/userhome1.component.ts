import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute, ParamMap } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { UserService } from '../user.service';

@Component({
  selector: 'app-userhome1',
  templateUrl: './userhome1.component.html',
  styleUrls: ['./userhome1.component.css']
})
export class Userhome1Component implements OnInit {

  msg: string;
  public persondata = [];
  constructor(private incomingrouter: ActivatedRoute, private service: UserService, private http: HttpClient) { }

  ngOnInit(): void {
    this.msg = (this.incomingrouter.snapshot.paramMap.get("p2"));
    this.service.getData().subscribe((data) => {
      this.persondata = Array.from(Object.keys(data), k => data[k]);
    });

  }
}​​​​​​​​​​​​​​​​